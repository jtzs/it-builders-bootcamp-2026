# Student Code Uploader — Plan

## Top-Level Overview

A Python Flask web app for classroom use on a local intranet.
Students visit the app, create a named folder, and upload HTML/CSS/JS files.
Uploaded files are immediately served as a live website at `/<folder-name>/`.

No student authentication — the app is intranet-only (not exposed to the internet).
A password-protected **admin page** lets the teacher delete individual files or entire student folders.

---

## Architecture

```
Browser
  │
  ├─ GET  /                          → landing page (create/enter folder)
  ├─ POST /create                    → create a new student folder
  ├─ GET  /<folder>/manage           → file manager for that folder
  ├─ POST /<folder>/upload           → upload one or more files
  ├─ POST /<folder>/delete/<file>    → delete a single file
  ├─ GET  /<folder>/                 → serve index.html (or directory listing)
  ├─ GET  /<folder>/<path:filename>  → serve any uploaded static file
  │
  ├─ GET  /admin                     → admin login page
  ├─ POST /admin/login               → validate admin password, set session
  ├─ GET  /admin/dashboard           → list all student folders + files
  ├─ POST /admin/delete-file         → delete a specific file from any folder
  └─ POST /admin/delete-folder       → delete an entire student folder
```

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffold

**Intent**
Set up the Flask project structure, dependencies, and configuration so every subsequent sub-task has a working base to build on.

**Expected Outcomes**
- `requirements.txt` with `flask` and `python-dotenv`
- `app/__init__.py` creates the Flask app and loads config from `.env`
- `app/config.py` exposes `UPLOAD_FOLDER`, `ALLOWED_EXTENSIONS`, `ADMIN_PASSWORD`, `SECRET_KEY`
- `run.py` entry-point
- `uploads/` directory (git-ignored) where student folders will live
- `.env.example` documenting all env vars
- `.gitignore`

**Todo List**
1. Create directory layout: `app/`, `app/templates/`, `app/static/`, `uploads/`
2. Write `app/config.py` — read env vars with sensible defaults (`UPLOAD_FOLDER=uploads`, `ADMIN_PASSWORD=admin`)
3. Write `app/__init__.py` — Flask app factory, `SECRET_KEY` for sessions, register blueprints placeholder
4. Write `run.py`
5. Write `requirements.txt`
6. Write `.env.example` and `.gitignore`

**Relevant Context**
- No existing code; greenfield
- `ADMIN_PASSWORD` and `SECRET_KEY` are the only secrets — loaded from `.env`

**Status** — `[x] done`

---

### Sub-Task 2 — Folder Creation Route

**Intent**
Let a student name their folder to claim a workspace on the server.

**Expected Outcomes**
- `GET /` renders a landing page with a single "folder name" input form
- `POST /create` validates and sanitises the folder name, creates it under `uploads/`, redirects to `/<folder>/manage`
- Folder names are restricted to alphanumeric characters, hyphens, and underscores (max 40 chars) to prevent path traversal
- If the folder already exists, show an inline warning ("this folder already exists") with a "Continue anyway" confirm button that proceeds to `/<folder>/manage`
- Error messages shown inline for invalid names

**Todo List**
1. Create `app/routes/main.py` blueprint with `GET /` and `POST /create`
2. Write `app/templates/index.html` — simple folder-name form
3. Add folder-name sanitisation utility in `app/utils.py`
4. Wire blueprint into `app/__init__.py`

**Relevant Context**
- `UPLOAD_FOLDER` from config is the root; student folder lives at `UPLOAD_FOLDER/<folder_name>/`
- Sanitisation must reject names like `../etc` or empty strings

**Status** — `[x] done`

---

### Sub-Task 3 — File Upload & Delete Routes

**Intent**
Allow students to upload one or more files into their folder and delete individual files they no longer need.

**Expected Outcomes**
- `GET /<folder>/manage` renders a file manager listing current files with delete buttons and a multi-file upload form
- `POST /<folder>/upload` accepts `multipart/form-data` with one or more files, validates extensions, saves to `uploads/<folder>/`; if any uploaded filename already exists a flash warning is shown listing the overwritten files (files are still saved)
- `POST /<folder>/delete/<filename>` removes the named file from disk and redirects back to the manage page
- Only safe web extensions allowed: `.html`, `.css`, `.js`, `.png`, `.jpg`, `.jpeg`, `.gif`, `.svg`, `.ico`, `.woff`, `.woff2`, `.ttf`
- Files that would escape the folder (path traversal) are rejected with a 400

**Todo List**
1. Add routes `GET /<folder>/manage`, `POST /<folder>/upload`, `POST /<folder>/delete/<filename>` to `app/routes/main.py`
2. Write `app/templates/manage.html` — file list table, multi-file upload form (`multiple` attribute), delete buttons per file
3. Add extension-validation helper to `app/utils.py`
4. Use `werkzeug.utils.secure_filename` for all saved filenames

**Relevant Context**
- `request.files.getlist('files')` handles multiple file inputs
- If the target folder does not exist, return 404

**Status** — `[x] done`

---

### Sub-Task 4 — Static File Serving

**Intent**
Serve uploaded files at `/<folder>/<filepath>` so a student's project is immediately live in the browser.

**Expected Outcomes**
- `GET /<folder>/` serves `uploads/<folder>/index.html` if it exists; otherwise renders a simple directory listing
- `GET /<folder>/<path:filename>` streams the correct file with the right MIME type
- Path traversal attempts return 404
- No extra libraries — `flask.send_from_directory` handles MIME types and traversal safety

**Todo List**
1. Add `GET /<folder>/` and `GET /<folder>/<path:filename>` routes to `app/routes/main.py`
2. Use `send_from_directory(os.path.join(UPLOAD_FOLDER, folder), filename)`
3. Add a minimal `app/templates/directory_listing.html` for when no `index.html` exists

**Relevant Context**
- These routes must be registered **after** `/manage`, `/upload`, and `/delete` routes to avoid conflicts
- `send_from_directory` with an absolute base path already prevents directory traversal

**Status** — `[x] done`

---

### Sub-Task 5 — Admin Page

**Intent**
Give the teacher a password-protected dashboard to view and clean up all student folders and files.

**Expected Outcomes**
- `GET /admin` shows a login form; if already logged in, redirects to dashboard
- `POST /admin/login` checks password against `ADMIN_PASSWORD` env var; on success sets `session['admin'] = True` and redirects to dashboard
- `GET /admin/dashboard` lists every student folder and the files inside each one; protected by session check (redirects to login if not authenticated)
- `POST /admin/delete-file` accepts `folder` + `filename` form fields, deletes the file, redirects back to dashboard
- `POST /admin/delete-folder` accepts `folder` form field, deletes the entire folder and all its contents, redirects back to dashboard
- `GET /admin/logout` clears the session and redirects to `/admin`

**Todo List**
1. Create `app/routes/admin.py` blueprint with prefix `/admin`
2. Write a `require_admin` decorator that checks `session['admin']` and redirects to `/admin` if not set
3. Write `app/templates/admin/login.html` — single password form
4. Write `app/templates/admin/dashboard.html` — table of folders/files, delete buttons for files and whole folders
5. Wire the admin blueprint into `app/__init__.py`

**Relevant Context**
- `SECRET_KEY` must be set (non-default) for Flask sessions to be secure
- Folder deletion uses `shutil.rmtree`
- Admin password is plain-text comparison against `ADMIN_PASSWORD` from `.env`; acceptable for intranet classroom use

**Status** — `[x] done`

---

### Sub-Task 6 — UI Polish & README

**Intent**
Make the UI clean and usable in a classroom and document how to run the app.

**Expected Outcomes**
- `app/templates/base.html` with minimal inline CSS (no external CDN — intranet-safe)
- All templates extend `base.html`
- `README.md` covering: install, env vars, running (`flask run --host=0.0.0.0`), accessing the admin page, deployment note

**Todo List**
1. Write `app/templates/base.html` with clean, readable, mobile-friendly inline CSS
2. Refactor all templates (`index.html`, `manage.html`, `directory_listing.html`, `admin/login.html`, `admin/dashboard.html`) to extend `base.html`
3. Write `README.md`

**Relevant Context**
- No external CDN — the app runs on an offline classroom intranet
- Keep styles minimal — this is a utility tool, not a product

**Status** — `[x] done`
