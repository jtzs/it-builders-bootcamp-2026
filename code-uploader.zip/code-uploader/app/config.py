import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-in-production")
    UPLOAD_FOLDER = os.path.join(
        BASE_DIR, "..", os.environ.get("UPLOAD_FOLDER", "uploads")
    )
    UPLOAD_FOLDER = os.path.abspath(UPLOAD_FOLDER)
    ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin")
    ALLOWED_EXTENSIONS = {
        "html", "css", "js",
        "png", "jpg", "jpeg", "gif", "svg", "ico",
        "woff", "woff2", "ttf",
    }
    MAX_CONTENT_LENGTH = 32 * 1024 * 1024  # 32 MB max upload size
