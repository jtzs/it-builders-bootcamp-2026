import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-in-production")
    _upload_folder_env = os.environ.get("UPLOAD_FOLDER", "uploads")
    UPLOAD_FOLDER = (
        _upload_folder_env
        if os.path.isabs(_upload_folder_env)
        else os.path.abspath(os.path.join(BASE_DIR, "..", _upload_folder_env))
    )
    ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin")
    ALLOWED_EXTENSIONS = {
        "html", "css", "js", "json",
        "png", "jpg", "jpeg", "gif", "svg", "ico",
        "woff", "woff2", "ttf",
    }
    MAX_CONTENT_LENGTH = 32 * 1024 * 1024  # 32 MB max upload size
