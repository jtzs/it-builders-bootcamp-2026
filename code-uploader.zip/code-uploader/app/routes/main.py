import os
from flask import (
    Blueprint, render_template, request, redirect, url_for,
    current_app, flash, abort, send_from_directory,
)
from werkzeug.utils import secure_filename
from app.utils import is_valid_folder_name, is_allowed_extension, is_safe_path

main_bp = Blueprint("main", __name__)


# ---------------------------------------------------------------------------
# Landing page & folder creation
# ---------------------------------------------------------------------------

@main_bp.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@main_bp.route("/create", methods=["POST"])
def create_folder():
    folder_name = request.form.get("folder_name", "").strip()

    if not is_valid_folder_name(folder_name):
        flash("Invalid folder name. Use only letters, numbers, hyphens and underscores (max 40 chars).", "error")
        return render_template("index.html", folder_name=folder_name)

    folder_path = os.path.join(current_app.config["UPLOAD_FOLDER"], folder_name)
    folder_exists = os.path.isdir(folder_path)

    # If the folder already exists the form must carry a confirmation flag
    if folder_exists and not request.form.get("confirmed"):
        return render_template(
            "index.html",
            folder_name=folder_name,
            folder_exists=True,
        )

    os.makedirs(folder_path, exist_ok=True)
    return redirect(url_for("main.manage_folder", folder_name=folder_name))


# ---------------------------------------------------------------------------
# File manager
# ---------------------------------------------------------------------------

@main_bp.route("/<folder_name>/manage", methods=["GET"])
def manage_folder(folder_name):
    if not is_valid_folder_name(folder_name):
        abort(404)

    folder_path = os.path.join(current_app.config["UPLOAD_FOLDER"], folder_name)
    if not os.path.isdir(folder_path):
        abort(404)

    files = sorted(
        f for f in os.listdir(folder_path)
        if os.path.isfile(os.path.join(folder_path, f))
    )
    return render_template("manage.html", folder_name=folder_name, files=files)


# ---------------------------------------------------------------------------
# Upload files
# ---------------------------------------------------------------------------

@main_bp.route("/<folder_name>/upload", methods=["POST"])
def upload_files(folder_name):
    if not is_valid_folder_name(folder_name):
        abort(404)

    folder_path = os.path.join(current_app.config["UPLOAD_FOLDER"], folder_name)
    if not os.path.isdir(folder_path):
        abort(404)

    uploaded = request.files.getlist("files")
    if not uploaded or all(f.filename == "" for f in uploaded):
        flash("No files selected.", "error")
        return redirect(url_for("main.manage_folder", folder_name=folder_name))

    allowed = current_app.config["ALLOWED_EXTENSIONS"]
    overwritten = []
    rejected = []
    saved = 0

    for file in uploaded:
        if file.filename == "":
            continue
        filename = secure_filename(file.filename)
        if not is_allowed_extension(filename, allowed):
            rejected.append(filename)
            continue
        dest = os.path.join(folder_path, filename)
        if os.path.exists(dest):
            overwritten.append(filename)
        file.save(dest)
        saved += 1

    if overwritten:
        flash(
            f"Warning: the following file(s) were overwritten: {', '.join(overwritten)}",
            "warning",
        )
    if rejected:
        flash(
            f"The following file(s) were skipped (unsupported extension): {', '.join(rejected)}",
            "error",
        )
    if saved:
        flash(f"{saved} file(s) uploaded successfully.", "success")

    return redirect(url_for("main.manage_folder", folder_name=folder_name))


# ---------------------------------------------------------------------------
# Delete a single file
# ---------------------------------------------------------------------------

@main_bp.route("/<folder_name>/delete/<path:filename>", methods=["POST"])
def delete_file(folder_name, filename):
    if not is_valid_folder_name(folder_name):
        abort(404)

    folder_path = os.path.join(current_app.config["UPLOAD_FOLDER"], folder_name)
    # Prevent path traversal
    target = os.path.join(folder_path, filename)
    if not is_safe_path(folder_path, target):
        abort(400)

    if os.path.isfile(target):
        os.remove(target)
        flash(f"'{filename}' deleted.", "success")
    else:
        flash(f"'{filename}' not found.", "error")

    return redirect(url_for("main.manage_folder", folder_name=folder_name))


# ---------------------------------------------------------------------------
# Serve uploaded static files
# ---------------------------------------------------------------------------

@main_bp.route("/<folder_name>/")
def serve_index(folder_name):
    if not is_valid_folder_name(folder_name):
        abort(404)

    folder_path = os.path.join(current_app.config["UPLOAD_FOLDER"], folder_name)
    if not os.path.isdir(folder_path):
        abort(404)

    if os.path.isfile(os.path.join(folder_path, "index.html")):
        return send_from_directory(folder_path, "index.html")

    files = sorted(
        f for f in os.listdir(folder_path)
        if os.path.isfile(os.path.join(folder_path, f))
    )
    return render_template("directory_listing.html", folder_name=folder_name, files=files)


@main_bp.route("/<folder_name>/<path:filename>")
def serve_file(folder_name, filename):
    if not is_valid_folder_name(folder_name):
        abort(404)

    folder_path = os.path.join(current_app.config["UPLOAD_FOLDER"], folder_name)
    if not os.path.isdir(folder_path):
        abort(404)

    return send_from_directory(folder_path, filename)
