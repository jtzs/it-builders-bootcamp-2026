import os
import shutil
from functools import wraps
from flask import (
    Blueprint, render_template, request, redirect,
    url_for, session, flash, abort, current_app,
)
from app.utils import is_valid_folder_name

admin_bp = Blueprint("admin", __name__)


# ---------------------------------------------------------------------------
# Auth decorator
# ---------------------------------------------------------------------------

def require_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin.login"))
        return f(*args, **kwargs)
    return decorated


# ---------------------------------------------------------------------------
# Login / logout
# ---------------------------------------------------------------------------

@admin_bp.route("/", methods=["GET"])
def login():
    if session.get("admin"):
        return redirect(url_for("admin.dashboard"))
    return render_template("admin/login.html")


@admin_bp.route("/login", methods=["POST"])
def do_login():
    password = request.form.get("password", "")
    if password == current_app.config["ADMIN_PASSWORD"]:
        session["admin"] = True
        return redirect(url_for("admin.dashboard"))
    flash("Incorrect password.", "error")
    return render_template("admin/login.html")


@admin_bp.route("/logout")
def logout():
    session.pop("admin", None)
    return redirect(url_for("admin.login"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@admin_bp.route("/dashboard")
@require_admin
def dashboard():
    upload_root = current_app.config["UPLOAD_FOLDER"]
    folders = {}
    if os.path.isdir(upload_root):
        for folder_name in sorted(os.listdir(upload_root)):
            folder_path = os.path.join(upload_root, folder_name)
            if os.path.isdir(folder_path):
                folders[folder_name] = sorted(os.listdir(folder_path))
    return render_template("admin/dashboard.html", folders=folders)


# ---------------------------------------------------------------------------
# Delete file
# ---------------------------------------------------------------------------

@admin_bp.route("/delete-file", methods=["POST"])
@require_admin
def delete_file():
    folder_name = request.form.get("folder", "").strip()
    filename = request.form.get("filename", "").strip()

    if not is_valid_folder_name(folder_name) or not filename:
        abort(400)

    upload_root = current_app.config["UPLOAD_FOLDER"]
    folder_path = os.path.join(upload_root, folder_name)
    target = os.path.realpath(os.path.join(folder_path, filename))

    # Prevent path traversal
    if not target.startswith(os.path.realpath(folder_path) + os.sep):
        abort(400)

    if os.path.isfile(target):
        os.remove(target)
        flash(f"Deleted '{filename}' from '{folder_name}'.", "success")
    else:
        flash(f"File '{filename}' not found.", "error")

    return redirect(url_for("admin.dashboard"))


# ---------------------------------------------------------------------------
# Delete folder
# ---------------------------------------------------------------------------

@admin_bp.route("/delete-folder", methods=["POST"])
@require_admin
def delete_folder():
    folder_name = request.form.get("folder", "").strip()

    if not is_valid_folder_name(folder_name):
        abort(400)

    upload_root = current_app.config["UPLOAD_FOLDER"]
    folder_path = os.path.join(upload_root, folder_name)

    if os.path.isdir(folder_path):
        shutil.rmtree(folder_path)
        flash(f"Folder '{folder_name}' deleted.", "success")
    else:
        flash(f"Folder '{folder_name}' not found.", "error")

    return redirect(url_for("admin.dashboard"))
