import re
import os


FOLDER_NAME_RE = re.compile(r'^[a-zA-Z0-9_-]{1,40}$')
RESERVED_NAMES = {
    "admin",
    "create",
    "static",
    "favicon.ico",
    "robots.txt",
    "login",
    "logout",
    "api",
}


def is_valid_folder_name(name: str) -> bool:
    """Return True if name is a safe, valid student folder name and not reserved."""
    if not name or not FOLDER_NAME_RE.match(name):
        return False
    return name.lower() not in RESERVED_NAMES


def is_allowed_extension(filename: str, allowed: set) -> bool:
    """Return True if the file's extension is in the allowed set."""
    _, ext = os.path.splitext(filename)
    return ext.lstrip('.').lower() in allowed


def is_safe_path(base_dir: str, path: str) -> bool:
    """Check if the resolved path is inside base_dir."""
    base_real = os.path.realpath(base_dir)
    target_real = os.path.realpath(path)
    return os.path.commonpath([base_real, target_real]) == base_real
