import re
import os


FOLDER_NAME_RE = re.compile(r'^[a-zA-Z0-9_-]{1,40}$')


def is_valid_folder_name(name: str) -> bool:
    """Return True if name is a safe, valid student folder name."""
    return bool(name and FOLDER_NAME_RE.match(name))


def is_allowed_extension(filename: str, allowed: set) -> bool:
    """Return True if the file's extension is in the allowed set."""
    _, ext = os.path.splitext(filename)
    return ext.lstrip('.').lower() in allowed
