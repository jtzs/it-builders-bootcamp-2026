# Student Code Uploader

A lightweight Flask web app for classroom use. Students create a named folder and upload their HTML/CSS/JS files. Each folder is immediately served as a live website at `/<folder-name>/`.

A password-protected admin dashboard lets the teacher delete individual files or entire student folders.

---

## Requirements

- Python 3.9+
- pip

---

## Installation

```bash
# 1. Clone / download the project
cd code-uploader

# 2. Create and activate a virtual environment
python -m venv venv
# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment variables
cp .env.example .env
# Edit .env and set a strong SECRET_KEY and ADMIN_PASSWORD
```

---

## Configuration (`.env`)

| Variable        | Default   | Description                                          |
|-----------------|-----------|------------------------------------------------------|
| `SECRET_KEY`    | `change-me-in-production` | Flask session secret — change this! |
| `UPLOAD_FOLDER` | `uploads` | Directory where student folders are stored           |
| `ADMIN_PASSWORD`| `admin`   | Password for the teacher admin dashboard             |

---

## Running the app

### Development (single machine)

```bash
flask --app run run --debug
```

App is available at `http://127.0.0.1:5000`.

### Classroom / intranet (accessible to all students on the same network)

```bash
flask --app run run --host=0.0.0.0 --port=5000
```

Students connect to `http://<your-ip-address>:5000`.

To find your IP address:
- **Windows**: `ipconfig` → look for IPv4 Address
- **macOS/Linux**: `ifconfig` or `ip a`

> ⚠️ Do **not** expose this app to the public internet. It has no student authentication and is designed for trusted local networks only.

---

## How it works

### Students

1. Visit `http://<server-ip>:5000`
2. Enter a folder name (e.g. `alice` or `john-smith`)
3. Upload HTML, CSS, JS and image files via the file manager
4. Their site is immediately live at `http://<server-ip>:5000/<folder-name>/`

### Teacher (Admin)

1. Visit `http://<server-ip>:5000/admin`
2. Log in with the `ADMIN_PASSWORD` from `.env`
3. View all student folders and files
4. Delete individual files or entire folders

---

## Project structure

```
code-uploader/
├── app/
│   ├── __init__.py          # Flask app factory
│   ├── config.py            # Configuration from env vars
│   ├── utils.py             # Validation helpers
│   ├── routes/
│   │   ├── main.py          # Student routes (create, upload, serve)
│   │   └── admin.py         # Admin routes (login, dashboard, delete)
│   └── templates/
│       ├── base.html        # Shared layout + CSS
│       ├── index.html       # Landing page
│       ├── manage.html      # Student file manager
│       ├── directory_listing.html
│       └── admin/
│           ├── login.html
│           └── dashboard.html
├── uploads/                 # Student folders (git-ignored)
├── run.py                   # Entry point
├── requirements.txt
├── .env.example
└── README.md
```

---

## Allowed file extensions

`.html` `.css` `.js` `.json` `.png` `.jpg` `.jpeg` `.gif` `.svg` `.ico` `.woff` `.woff2` `.ttf`

---

## Security notes

- Folder names are restricted to `[a-zA-Z0-9_-]` (max 40 chars) to prevent path traversal.
- `werkzeug.utils.secure_filename` is applied to all uploaded filenames.
- `send_from_directory` with an absolute base path prevents directory traversal in file serving.
- The admin password is stored in plain text in `.env` — acceptable for a closed classroom intranet.
- Set `SECRET_KEY` to a long random string so session cookies cannot be forged.
